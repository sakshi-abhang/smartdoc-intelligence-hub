# SmartDoc Intelligence Hub Deployment

## Streamlit Community Cloud
1. Upload `app.py` and `requirements.txt` to the root of your GitHub repository.
2. In Streamlit Community Cloud, create or update the app.
3. Choose the repository, branch `main`, and entrypoint `app.py`.
4. Deploy.

## Recommended runtime settings
- OCR mode: Fast (recommended)
- Handwriting OCR: Off unless handwritten dimensions are required

The MAERSK logo is embedded in `app.py`; no separate image file is required.
